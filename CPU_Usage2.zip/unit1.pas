unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs,
  ExtCtrls, Windows;

const
  ANZ = 60;              // Anzahl Messwerte im Verlaufsgraph (60 Sekunden)
  DSL_DOWN_MBIT = 50;    // deine Download-Geschwindigkeit
  DSL_UP_MBIT = 20;      // deine Upload-Geschwindigkeit

type
  TVerlauf = array[0..ANZ - 1] of Double;

  TForm1 = class(TForm)
  private
    FBox: TPaintBox;
    FTimer: TTimer;
    FLetztIdle, FLetztKernel, FLetztUser: UInt64;
    FLetztRx, FLetztTx: Cardinal;
    FCpu, FRam, FDown, FUp: TVerlauf;   // Verlauf in Prozent (0..100)
    FCpuProz, FRamProz: Integer;
    FRamBelegtGB, FRamGesamtGB: Double;
    FMbitDown, FMbitUp: Double;
    function FileTimeZuInt(const ft: TFileTime): UInt64;
    function HoleNetzBytes(out rx, tx: Cardinal): Boolean;
    procedure TimerTick(Sender: TObject);
    procedure BoxPaint(Sender: TObject);
  public
    constructor Create(TheOwner: TComponent); override;
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

type
  TMemStatusEx = record
    dwLength: DWORD;
    dwMemoryLoad: DWORD;
    ullTotalPhys: UInt64;
    ullAvailPhys: UInt64;
    ullTotalPageFile: UInt64;
    ullAvailPageFile: UInt64;
    ullTotalVirtual: UInt64;
    ullAvailVirtual: UInt64;
    ullAvailExtendedVirtual: UInt64;
  end;

  TMibIfRow = record
    wszName: array[0..255] of WideChar;
    dwIndex: DWORD;
    dwType: DWORD;
    dwMtu: DWORD;
    dwSpeed: DWORD;
    dwPhysAddrLen: DWORD;
    bPhysAddr: array[0..7] of Byte;
    dwAdminStatus: DWORD;
    dwOperStatus: DWORD;
    dwLastChange: DWORD;
    dwInOctets: DWORD;
    dwInUcastPkts: DWORD;
    dwInNUcastPkts: DWORD;
    dwInDiscards: DWORD;
    dwInErrors: DWORD;
    dwInUnknownProtos: DWORD;
    dwOutOctets: DWORD;
    dwOutUcastPkts: DWORD;
    dwOutNUcastPkts: DWORD;
    dwOutDiscards: DWORD;
    dwOutErrors: DWORD;
    dwOutQLen: DWORD;
    dwDescrLen: DWORD;
    bDescr: array[0..255] of Byte;
  end;
  PMibIfRow = ^TMibIfRow;

const
  IF_TYPE_LOOPBACK = 24;

  // Farben (Hintergrund und Kacheln)
  FARBE_HINTERGRUND = TColor($00201E1C);
  FARBE_KACHEL      = TColor($00302D2A);
  FARBE_GRAPH       = TColor($00252320);
  FARBE_BALKEN_BG   = TColor($00494540);
  FARBE_TEXT_HELL   = TColor($00F0F0F0);
  FARBE_TEXT_GRAU   = TColor($00A8A29C);

function GetSystemTimes(lpIdleTime, lpKernelTime, lpUserTime: PFileTime): BOOL;
  stdcall; external 'kernel32.dll' name 'GetSystemTimes';

function GlobalMemStatusEx(var lpBuffer: TMemStatusEx): BOOL;
  stdcall; external 'kernel32.dll' name 'GlobalMemoryStatusEx';

function GetIfTable(pIfTable: Pointer; var pdwSize: ULONG; bOrder: BOOL): DWORD;
  stdcall; external 'iphlpapi.dll' name 'GetIfTable';

{ ---------- Hilfsfunktionen ---------- }

function Begrenze(w: Double): Double;
begin
  if w < 0 then w := 0;
  if w > 100 then w := 100;
  Result := w;
end;

function Rechteck(l, t, r, b: Integer): TRect;
begin
  Result.Left := l;
  Result.Top := t;
  Result.Right := r;
  Result.Bottom := b;
end;

// mischt zwei Farben; p = Anteil von a in Prozent
function Mischen(a, b: TColor; p: Integer): TColor;
var
  ar, ag, ab, br, bg, bb: Integer;
begin
  ar := a and $FF;  ag := (a shr 8) and $FF;  ab := (a shr 16) and $FF;
  br := b and $FF;  bg := (b shr 8) and $FF;  bb := (b shr 16) and $FF;
  Result := TColor(
    ((ar * p + br * (100 - p)) div 100) or
    (((ag * p + bg * (100 - p)) div 100) shl 8) or
    (((ab * p + bb * (100 - p)) div 100) shl 16));
end;

// Ampel: gruen bis 60 %, gelb bis 85 %, darueber rot
function AmpelFarbe(proz: Double): TColor;
begin
  if proz < 60 then
    Result := RGBToColor(80, 200, 120)
  else if proz < 85 then
    Result := RGBToColor(240, 190, 60)
  else
    Result := RGBToColor(230, 70, 70);
end;

procedure Schiebe(var v: TVerlauf; neu: Double);
begin
  Move(v[1], v[0], (ANZ - 1) * SizeOf(Double));
  v[ANZ - 1] := Begrenze(neu);
end;

procedure TextMittig(c: TCanvas; const r: TRect; y: Integer; const s: string);
begin
  c.TextOut(r.Left + ((r.Right - r.Left) - c.TextWidth(s)) div 2, y, s);
end;

procedure ZeichneKachel(c: TCanvas; const r: TRect; const titel, wert, detail: string;
  proz: Double; farbe: TColor; const verlauf: TVerlauf);
var
  bx, by, bw, bh, gx, gy, gw, gh, n, fuellung: Integer;
  pts: array of TPoint;
begin
  // Kachel
  c.Brush.Style := bsSolid;
  c.Pen.Style := psClear;
  c.Brush.Color := FARBE_KACHEL;
  c.RoundRect(r.Left, r.Top, r.Right, r.Bottom, 16, 16);

  // Texte
  c.Brush.Style := bsClear;
  c.Font.Name := 'Segoe UI';

  c.Font.Size := 10;
  c.Font.Style := [];
  c.Font.Color := FARBE_TEXT_GRAU;
  TextMittig(c, r, r.Top + 8, titel);

  c.Font.Size := 24;
  c.Font.Style := [fsBold];
  c.Font.Color := farbe;
  TextMittig(c, r, r.Top + 24, wert);

  c.Font.Size := 9;
  c.Font.Style := [];
  c.Font.Color := FARBE_TEXT_HELL;
  TextMittig(c, r, r.Top + 62, detail);

  // Balken
  bx := r.Left + 10;
  by := r.Top + 82;
  bw := (r.Right - r.Left) - 20;
  bh := 8;
  c.Brush.Style := bsSolid;
  c.Brush.Color := FARBE_BALKEN_BG;
  c.RoundRect(bx, by, bx + bw, by + bh, 8, 8);
  fuellung := Round(bw * Begrenze(proz) / 100);
  if fuellung >= 8 then
  begin
    c.Brush.Color := farbe;
    c.RoundRect(bx, by, bx + fuellung, by + bh, 8, 8);
  end;

  // Verlaufsgraph
  gx := r.Left + 10;
  gy := r.Top + 98;
  gw := (r.Right - r.Left) - 20;
  gh := r.Bottom - 8 - gy;
  c.Brush.Color := FARBE_GRAPH;
  c.FillRect(gx, gy, gx + gw, gy + gh);

  SetLength(pts, ANZ + 2);
  for n := 0 to ANZ - 1 do
  begin
    pts[n].X := gx + Round(n * (gw - 1) / (ANZ - 1));
    pts[n].Y := gy + gh - 1 - Round((gh - 2) * verlauf[n] / 100);
  end;
  pts[ANZ].X := gx + gw - 1;
  pts[ANZ].Y := gy + gh - 1;
  pts[ANZ + 1].X := gx;
  pts[ANZ + 1].Y := gy + gh - 1;

  // gefuellte Flaeche (abgedunkelte Farbe) ...
  c.Pen.Style := psClear;
  c.Brush.Color := Mischen(farbe, FARBE_GRAPH, 35);
  c.Polygon(pts);

  // ... und Linie oben drauf
  c.Pen.Style := psSolid;
  c.Pen.Width := 2;
  c.Pen.Color := farbe;
  c.Polyline(pts, 0, ANZ);
  c.Pen.Width := 1;
end;

{ ---------- TForm1 ---------- }

constructor TForm1.Create(TheOwner: TComponent);
var
  idle, kernel, user: TFileTime;
  rx, tx: Cardinal;
begin
  inherited Create(TheOwner);

  Caption := 'System-Monitor';
  BorderStyle := bsSingle;
  BorderIcons := [biSystemMenu, biMinimize];
  Position := poScreenCenter;
  Color := FARBE_HINTERGRUND;
  DoubleBuffered := True;
  ClientWidth := 440;
  ClientHeight := 330;
  FormStyle := fsSystemStayOnTop;

  FBox := TPaintBox.Create(Self);
  FBox.Parent := Self;
  FBox.Align := alClient;
  FBox.OnPaint := @BoxPaint;

  FTimer := TTimer.Create(Self);
  FTimer.Interval := 1000;
  FTimer.OnTimer := @TimerTick;

  FillChar(FCpu, SizeOf(FCpu), 0);
  FillChar(FRam, SizeOf(FRam), 0);
  FillChar(FDown, SizeOf(FDown), 0);
  FillChar(FUp, SizeOf(FUp), 0);

  GetSystemTimes(@idle, @kernel, @user);
  FLetztIdle := FileTimeZuInt(idle);
  FLetztKernel := FileTimeZuInt(kernel);
  FLetztUser := FileTimeZuInt(user);

  if HoleNetzBytes(rx, tx) then
  begin
    FLetztRx := rx;
    FLetztTx := tx;
  end;
end;

function TForm1.FileTimeZuInt(const ft: TFileTime): UInt64;
begin
  Result := (UInt64(ft.dwHighDateTime) shl 32) or ft.dwLowDateTime;
end;

function TForm1.HoleNetzBytes(out rx, tx: Cardinal): Boolean;
var
  size: ULONG;
  buf: Pointer;
  anzahl, n: DWORD;
  row: PMibIfRow;
begin
  Result := False;
  rx := 0;
  tx := 0;
  size := 0;
  GetIfTable(nil, size, False); // fragt nur die benoetigte Groesse ab
  if size = 0 then Exit;
  GetMem(buf, size);
  try
    if GetIfTable(buf, size, False) = 0 then
    begin
      anzahl := PDWORD(buf)^;
      for n := 0 to anzahl - 1 do
      begin
        row := PMibIfRow(PtrUInt(buf) + SizeOf(DWORD) + n * SizeOf(TMibIfRow));
        if row^.dwType <> IF_TYPE_LOOPBACK then
        begin
          // nicht addieren, sondern den groessten Zaehler nehmen,
          // sonst wird derselbe Verkehr durch Filter-Eintraege mehrfach gezaehlt
          if row^.dwInOctets > rx then rx := row^.dwInOctets;
          if row^.dwOutOctets > tx then tx := row^.dwOutOctets;
        end;
      end;
      Result := True;
    end;
  finally
    FreeMem(buf);
  end;
end;

procedure TForm1.TimerTick(Sender: TObject);
var
  idle, kernel, user: TFileTime;
  i, k, u, dIdle, dGesamt: UInt64;
  mem: TMemStatusEx;
  rx, tx, dRx, dTx: Cardinal;
begin
  // CPU
  GetSystemTimes(@idle, @kernel, @user);
  i := FileTimeZuInt(idle);
  k := FileTimeZuInt(kernel);
  u := FileTimeZuInt(user);

  dIdle := i - FLetztIdle;
  dGesamt := (k - FLetztKernel) + (u - FLetztUser); // Kernel enthält Idle

  if dGesamt > 0 then
    FCpuProz := Round(100 * (dGesamt - dIdle) / dGesamt)
  else
    FCpuProz := 0;

  FLetztIdle := i;
  FLetztKernel := k;
  FLetztUser := u;
  Schiebe(FCpu, FCpuProz);

  // RAM
  FillChar(mem, SizeOf(mem), 0);
  mem.dwLength := SizeOf(mem);
  if GlobalMemStatusEx(mem) then
  begin
    FRamProz := mem.dwMemoryLoad;
    FRamGesamtGB := mem.ullTotalPhys / (1024.0 * 1024 * 1024);
    FRamBelegtGB := (mem.ullTotalPhys - mem.ullAvailPhys) / (1024.0 * 1024 * 1024);
  end
  else
  begin
    FRamProz := 0;
    FRamGesamtGB := 0;
    FRamBelegtGB := 0;
  end;
  Schiebe(FRam, FRamProz);

  // Netzwerk (Timer-Intervall = 1000 ms)
  if HoleNetzBytes(rx, tx) then
  begin
    dRx := rx - FLetztRx;
    dTx := tx - FLetztTx;
    FMbitDown := dRx * 8 / 1000000;
    FMbitUp := dTx * 8 / 1000000;
    FLetztRx := rx;
    FLetztTx := tx;
  end;
  Schiebe(FDown, 100 * FMbitDown / DSL_DOWN_MBIT);
  Schiebe(FUp, 100 * FMbitUp / DSL_UP_MBIT);

  FBox.Invalidate;
end;

procedure TForm1.BoxPaint(Sender: TObject);
var
  c: TCanvas;
  w, h: Integer;
  downProz, upProz: Double;
begin
  c := FBox.Canvas;
  w := FBox.Width div 2;
  h := FBox.Height div 2;

  c.Brush.Style := bsSolid;
  c.Brush.Color := FARBE_HINTERGRUND;
  c.FillRect(0, 0, FBox.Width, FBox.Height);

  downProz := Begrenze(100 * FMbitDown / DSL_DOWN_MBIT);
  upProz := Begrenze(100 * FMbitUp / DSL_UP_MBIT);

  // oben links: CPU
  ZeichneKachel(c, Rechteck(6, 6, w - 6, h - 6),
    'CPU',
    Format('%d %%', [FCpuProz]), 'Prozessorauslastung',
    FCpuProz, AmpelFarbe(FCpuProz), FCpu);

  // oben rechts: RAM
  ZeichneKachel(c, Rechteck(w + 6, 6, 2 * w - 6, h - 6),
    'RAM',
    Format('%d %%', [FRamProz]),
    Format('%.1f von %.1f GB', [FRamBelegtGB, FRamGesamtGB]),
    FRamProz, AmpelFarbe(FRamProz), FRam);

  // unten links: Download
  ZeichneKachel(c, Rechteck(6, h + 6, w - 6, 2 * h - 6),
    'Download',
    Format('%.1f', [FMbitDown]),
    Format('Mbit/s (max. %d)', [DSL_DOWN_MBIT]),
    downProz, RGBToColor(70, 160, 240), FDown);

  // unten rechts: Upload
  ZeichneKachel(c, Rechteck(w + 6, h + 6, 2 * w - 6, 2 * h - 6),
    'Upload',
    Format('%.1f', [FMbitUp]),
    Format('Mbit/s (max. %d)', [DSL_UP_MBIT]),
    upProz, RGBToColor(250, 150, 50), FUp);
end;

end.
